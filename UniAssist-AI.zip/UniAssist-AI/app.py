"""Interface Gradio de UniAssist AI.

Lancement : python app.py
"""

from __future__ import annotations

import gradio as gr

from chatbot import (
    ChatbotError,
    InvalidInputError,
    UniAssistBot,
    load_encoder,
)
from config import CATEGORY_LABELS, SIMILARITY_THRESHOLD
from knowledge_base import KnowledgeBaseError, load_knowledge_base

LANGUAGE_CHOICES = [
    ("Détection automatique / كشف تلقائي", "auto"),
    ("Français", "fr"),
    ("العربية", "ar"),
]

EXAMPLES = [
    "Quels documents faut-il préparer pour une inscription universitaire ?",
    "Où puis-je obtenir mon certificat de scolarité ?",
    "Comment consulter mon emploi du temps ?",
    "ما هي الوثائق المطلوبة للتسجيل الجامعي؟",
    "كيف أطلع على جدول التوقيت؟",
    "كيف أستعد لفترة الامتحانات؟",
]

INTRO = """
# 🎓 UniAssist AI
**Assistant étudiant bilingue français-arabe basé sur le NLP.**
Posez une question sur les inscriptions, les documents administratifs, les examens,
les emplois du temps, les bourses ou la vie étudiante, en français ou en arabe.
"""

LIMITS = """
**Projet pédagogique – limites importantes**
- Les réponses sont **génériques et non officielles** : elles doivent être vérifiées auprès de l'administration de votre établissement.
- Le système retrouve la question la plus proche dans une petite base de connaissances ; il **ne génère pas** de texte et ne comprend pas tous les dialectes.
- Le score affiché est une **similarité cosinus**, ce n'est **pas** une probabilité que la réponse soit correcte.
- Si aucune question n'est assez proche (seuil actuel : {threshold:.2f}), le système refuse de répondre.

هذا مشروع تعليمي: الإجابات عامة وغير رسمية، ويجب التحقق منها لدى إدارة جامعتك.
"""

CSS = """
#chatbox .message, #chatbox .message * { unicode-bidi: plaintext; text-align: start; }
#question-box textarea { unicode-bidi: plaintext; text-align: start; }
"""


def build_bot() -> tuple[UniAssistBot | None, str | None]:
    """Construit le chatbot ; retourne (bot, None) ou (None, message d'erreur)."""
    try:
        entries = load_knowledge_base()
        encoder = load_encoder()
        return UniAssistBot(entries, encoder), None
    except (KnowledgeBaseError, ChatbotError) as exc:
        return None, str(exc)


def format_answer(response) -> str:
    """Ajoute la catégorie et le score cosinus sous la réponse."""
    if not response.found:
        return response.answer
    label = CATEGORY_LABELS.get(response.category, {}).get(response.language, response.category)
    if response.language == "ar":
        footer = f"\n\n*{label} · تشابه جيب التمام: {response.score:.2f}*"
    else:
        footer = f"\n\n*{label} · similarité cosinus : {response.score:.2f}*"
    return response.answer + footer


def create_demo(bot: UniAssistBot | None, startup_error: str | None) -> gr.Blocks:
    threshold = bot.threshold if bot else SIMILARITY_THRESHOLD

    def respond(message, history, language):
        history = list(history or [])
        if bot is None:
            status = f"❌ **Le chatbot n'est pas disponible.**\n\n{startup_error}"
            return history, message, status
        try:
            response = bot.answer(message, language)
        except InvalidInputError as exc:
            return history, message, f"⚠️ {exc}"
        history.append({"role": "user", "content": message})
        history.append({"role": "assistant", "content": format_answer(response)})
        if response.found:
            status = "✅ Réponse trouvée dans la base de connaissances."
        else:
            status = (
                "⚠️ **Aucune réponse suffisamment pertinente** : "
                f"meilleure similarité cosinus {response.score:.2f} < seuil {bot.threshold:.2f}."
            )
        return history, "", status

    def clear():
        return [], "", "Conversation effacée."

    with gr.Blocks(title="UniAssist AI", theme=gr.themes.Soft(), css=CSS) as demo:
        gr.Markdown(INTRO)
        if startup_error:
            gr.Markdown(f"❌ **Erreur au démarrage**\n\n{startup_error}")
        language = gr.Radio(LANGUAGE_CHOICES, value="auto", label="Langue de réponse / لغة الإجابة")
        chat = gr.Chatbot(type="messages", height=400, label="Conversation", elem_id="chatbox")
        status = gr.Markdown("")
        question = gr.Textbox(
            label="Votre question / سؤالك",
            placeholder="Écrivez votre question… / اكتب سؤالك…",
            lines=2,
            elem_id="question-box",
        )
        with gr.Row():
            send = gr.Button("Envoyer / إرسال", variant="primary")
            erase = gr.Button("Effacer / مسح")
        gr.Examples(examples=EXAMPLES, inputs=question, label="Exemples de questions / أمثلة")
        with gr.Accordion("Limites et caractère pédagogique / الحدود", open=False):
            gr.Markdown(LIMITS.format(threshold=threshold))

        inputs, outputs = [question, chat, language], [chat, question, status]
        fn = lambda q, h, lang: respond(q, h, lang)
        send.click(fn, inputs, outputs)
        question.submit(fn, inputs, outputs)
        erase.click(clear, None, outputs)
    return demo


def main() -> None:
    bot, error = build_bot()
    if error:
        print(f"[UniAssist AI] Erreur au démarrage :\n{error}")
    create_demo(bot, error).launch()


if __name__ == "__main__":
    main()
