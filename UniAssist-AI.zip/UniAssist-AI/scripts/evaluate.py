"""Évaluation reproductible de UniAssist AI avec le VRAI modèle d'embeddings.

Exemples :
    python scripts/evaluate.py --split dev --sweep     # calibrer le seuil
    python scripts/evaluate.py --split test            # évaluation finale

Le script n'invente rien : si le modèle ne peut pas être chargé, il s'arrête
avec un message d'erreur et n'écrit aucun rapport.
"""

from __future__ import annotations

import argparse
import json
import platform
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chatbot import ChatbotError, UniAssistBot, load_encoder  # noqa: E402
from config import (  # noqa: E402
    EVAL_SET_PATH,
    FAQ_PATH,
    MODEL_NAME,
    REPORTS_DIR,
    SIMILARITY_THRESHOLD,
)
from knowledge_base import KnowledgeBaseError, load_knowledge_base  # noqa: E402


def load_eval_items(path: Path, split: str) -> list[dict]:
    """Charge le jeu d'évaluation et filtre par split ('dev', 'test' ou 'all')."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Jeu d'évaluation introuvable : {path}")
    items = json.loads(path.read_text(encoding="utf-8"))["items"]
    return items if split == "all" else [i for i in items if i["split"] == split]


def collect_records(bot: UniAssistBot, items: list[dict]) -> list[dict]:
    """Interroge le moteur : un enregistrement par question (score et id du top-1)."""
    records = []
    for item in items:
        top = bot.search(item["question"])[0]
        records.append({**item, "top_id": top.entry_id, "top_score": top.score})
    return records


def _rate(num: int, den: int) -> float | None:
    return None if den == 0 else num / den


def compute_metrics(records: list[dict], threshold: float) -> dict:
    """Calcule les métriques à partir des enregistrements (fonction pure).

    Définitions :
    - top1_retrieval_accuracy : parmi les questions AVEC réponse attendue, part dont
      l'entrée classée première est la bonne (indépendant du seuil).
    - answered_correctly_rate : part des questions avec réponse attendue pour lesquelles
      le système répond (score >= seuil) ET avec la bonne entrée.
    - false_rejection_rate : part des questions avec réponse attendue refusées à tort.
    - wrong_answer_rate : part des questions avec réponse attendue où le système répond
      avec une MAUVAISE entrée.
    - correct_rejection_rate : parmi les questions SANS réponse attendue, part refusée.
    - false_acceptance_rate : 1 - correct_rejection_rate.
    Ce sont des métriques de RECHERCHE : elles ne mesurent ni la qualité linguistique
    des réponses ni leur exactitude administrative.
    """

    def summarize(subset: list[dict]) -> dict:
        ans = [r for r in subset if r["expected_id"] is not None]
        una = [r for r in subset if r["expected_id"] is None]
        top1 = sum(r["top_id"] == r["expected_id"] for r in ans)
        correct = sum(r["top_score"] >= threshold and r["top_id"] == r["expected_id"] for r in ans)
        false_rej = sum(r["top_score"] < threshold for r in ans)
        wrong = sum(r["top_score"] >= threshold and r["top_id"] != r["expected_id"] for r in ans)
        rejected = sum(r["top_score"] < threshold for r in una)
        mean = lambda xs: (sum(xs) / len(xs)) if xs else None  # noqa: E731
        return {
            "n_total": len(subset),
            "n_answerable": len(ans),
            "n_unanswerable": len(una),
            "top1_retrieval_accuracy": _rate(top1, len(ans)),
            "answered_correctly_rate": _rate(correct, len(ans)),
            "false_rejection_rate": _rate(false_rej, len(ans)),
            "wrong_answer_rate": _rate(wrong, len(ans)),
            "correct_rejection_rate": _rate(rejected, len(una)),
            "false_acceptance_rate": _rate(len(una) - rejected, len(una)),
            "mean_top_score_answerable": mean([r["top_score"] for r in ans]),
            "mean_top_score_unanswerable": mean([r["top_score"] for r in una]),
        }

    errors = []
    for r in records:
        accepted = r["top_score"] >= threshold
        if r["expected_id"] is None and accepted:
            errors.append({**r, "error": "fausse acceptation (aurait dû refuser)"})
        elif r["expected_id"] is not None and not accepted:
            errors.append({**r, "error": "faux rejet"})
        elif r["expected_id"] is not None and r["top_id"] != r["expected_id"]:
            errors.append({**r, "error": "mauvaise entrée retrouvée"})

    return {
        "threshold": threshold,
        "overall": summarize(records),
        "by_language": {
            lang: summarize([r for r in records if r["lang"] == lang]) for lang in ("fr", "ar")
        },
        "by_type": {
            t: summarize([r for r in records if r["type"] == t])
            for t in sorted({r["type"] for r in records})
        },
        "errors": errors,
    }


def sweep(records: list[dict], start: float = 0.30, stop: float = 0.80, step: float = 0.05) -> list[dict]:
    """Évalue plusieurs seuils pour aider à la calibration (à faire sur 'dev')."""
    rows, t = [], start
    while t <= stop + 1e-9:
        overall = compute_metrics(records, round(t, 2))["overall"]
        rows.append(
            {
                "threshold": round(t, 2),
                "answered_correctly_rate": overall["answered_correctly_rate"],
                "false_rejection_rate": overall["false_rejection_rate"],
                "correct_rejection_rate": overall["correct_rejection_rate"],
            }
        )
        t += step
    return rows


def _pct(value: float | None) -> str:
    return "n/a" if value is None else f"{100 * value:.1f} %"


def render_markdown(metrics: dict, meta: dict, sweep_rows: list[dict] | None) -> str:
    o = metrics["overall"]
    lines = [
        "# Rapport d'évaluation UniAssist AI",
        "",
        f"- Date : {meta['date']}",
        f"- Modèle : `{meta['model']}` (sentence-transformers {meta['st_version']})",
        f"- Jeu utilisé : split `{meta['split']}` ({o['n_total']} questions : "
        f"{o['n_answerable']} avec réponse attendue, {o['n_unanswerable']} sans)",
        f"- Seuil de similarité cosinus : {metrics['threshold']}",
        f"- Python : {meta['python']}",
        "",
        "> Petit jeu de test rédigé par une seule personne : ces chiffres sont indicatifs, "
        "pas une garantie de performance. Ce sont des métriques de recherche, pas de qualité linguistique.",
        "",
        "## Résultats",
        "",
        "| Ensemble | n | Top-1 recherche | Répond juste | Faux rejets | Mauvaises réponses | Rejets corrects (sans réponse) |",
        "|---|---|---|---|---|---|---|",
    ]
    for name, m in [("Global", o), ("Français", metrics["by_language"]["fr"]), ("Arabe", metrics["by_language"]["ar"])]:
        lines.append(
            f"| {name} | {m['n_total']} | {_pct(m['top1_retrieval_accuracy'])} | "
            f"{_pct(m['answered_correctly_rate'])} | {_pct(m['false_rejection_rate'])} | "
            f"{_pct(m['wrong_answer_rate'])} | {_pct(m['correct_rejection_rate'])} |"
        )
    lines += [
        "",
        f"Score cosinus moyen du top-1 : questions avec réponse = {o['mean_top_score_answerable']}, "
        f"questions sans réponse = {o['mean_top_score_unanswerable']}.",
        "",
        "## Rejet par type de question sans réponse",
        "",
        "| Type | n sans réponse | Rejets corrects |",
        "|---|---|---|",
    ]
    for t, m in metrics["by_type"].items():
        if m["n_unanswerable"]:
            lines.append(f"| {t} | {m['n_unanswerable']} | {_pct(m['correct_rejection_rate'])} |")
    if sweep_rows:
        lines += [
            "",
            "## Balayage du seuil (à utiliser sur `dev` uniquement)",
            "",
            "| Seuil | Répond juste | Faux rejets | Rejets corrects |",
            "|---|---|---|---|",
        ]
        for r in sweep_rows:
            lines.append(
                f"| {r['threshold']:.2f} | {_pct(r['answered_correctly_rate'])} | "
                f"{_pct(r['false_rejection_rate'])} | {_pct(r['correct_rejection_rate'])} |"
            )
    lines += ["", f"## Erreurs observées ({len(metrics['errors'])})", ""]
    for e in metrics["errors"]:
        lines.append(
            f"- `{e['id']}` [{e['lang']}/{e['type']}] « {e['question']} » → {e['error']} "
            f"(attendu : {e['expected_id']}, top-1 : {e['top_id']}, score : {e['top_score']:.3f})"
        )
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Évalue UniAssist AI.")
    parser.add_argument("--split", choices=["dev", "test", "all"], default="test")
    parser.add_argument("--threshold", type=float, default=SIMILARITY_THRESHOLD)
    parser.add_argument("--faq", type=Path, default=FAQ_PATH)
    parser.add_argument("--eval-set", type=Path, default=EVAL_SET_PATH)
    parser.add_argument("--output-dir", type=Path, default=REPORTS_DIR)
    parser.add_argument("--sweep", action="store_true", help="balayage de seuils")
    args = parser.parse_args(argv)

    try:
        entries = load_knowledge_base(args.faq)
        items = load_eval_items(args.eval_set, args.split)
        if not items:
            print("Aucune question dans ce split.", file=sys.stderr)
            return 1
        bot = UniAssistBot(entries, load_encoder(), threshold=args.threshold)
        records = collect_records(bot, items)
    except (KnowledgeBaseError, ChatbotError, FileNotFoundError) as exc:
        print(f"Évaluation impossible : {exc}", file=sys.stderr)
        return 1

    metrics = compute_metrics(records, args.threshold)
    try:
        import sentence_transformers

        st_version = sentence_transformers.__version__
    except Exception:  # pragma: no cover
        st_version = "inconnue"
    meta = {
        "date": datetime.now().isoformat(timespec="seconds"),
        "model": MODEL_NAME,
        "st_version": st_version,
        "split": args.split,
        "python": platform.python_version(),
    }
    sweep_rows = sweep(records) if args.sweep else None

    args.output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"evaluation_{args.split}"
    (args.output_dir / f"{stem}.json").write_text(
        json.dumps({"meta": meta, "metrics": metrics, "sweep": sweep_rows}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    report = render_markdown(metrics, meta, sweep_rows)
    (args.output_dir / f"{stem}.md").write_text(report, encoding="utf-8")
    print(report)
    print(f"Rapports écrits dans {args.output_dir}/{stem}.(md|json)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
