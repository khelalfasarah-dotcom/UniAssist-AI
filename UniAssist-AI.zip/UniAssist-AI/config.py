"""Configuration centrale de UniAssist AI.

Toutes les valeurs modifiables sont regroupées ici. Le seuil de similarité peut
être changé sans toucher au code via la variable d'environnement
UNIASSIST_THRESHOLD (exemple : UNIASSIST_THRESHOLD=0.55).
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
FAQ_PATH = BASE_DIR / "data" / "faq.json"
EVAL_SET_PATH = BASE_DIR / "data" / "eval_set.json"
REPORTS_DIR = BASE_DIR / "reports"

# Modèle préentraîné de Sentence Transformers (multilingue, utilisable sur CPU).
MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

# Nombre maximal de réponses candidates conservées pour une question.
TOP_K = 3

# Longueur maximale d'une question (en caractères) après normalisation.
MAX_QUESTION_LENGTH = 500

SUPPORTED_LANGUAGES = ("fr", "ar")

# Seuil de similarité cosinus par défaut. ATTENTION : valeur PROVISOIRE, non
# calibrée. Elle doit être ajustée avec `python scripts/evaluate.py --split dev --sweep`
# (voir docs/evaluation.md).
DEFAULT_THRESHOLD = 0.50


def _read_threshold() -> float:
    """Lit le seuil depuis l'environnement et vérifie qu'il est valide."""
    raw = os.environ.get("UNIASSIST_THRESHOLD")
    if raw is None:
        return DEFAULT_THRESHOLD
    try:
        value = float(raw)
    except ValueError as exc:
        raise ValueError(
            f"UNIASSIST_THRESHOLD doit être un nombre (reçu : {raw!r})."
        ) from exc
    if not -1.0 <= value <= 1.0:
        raise ValueError("UNIASSIST_THRESHOLD doit être compris entre -1 et 1.")
    return value


SIMILARITY_THRESHOLD = _read_threshold()

NO_ANSWER_MESSAGES = {
    "fr": (
        "Je ne dispose pas d'informations suffisamment pertinentes pour répondre "
        "à cette question. Veuillez consulter l'administration de votre "
        "établissement ou préciser votre demande."
    ),
    "ar": (
        "لا تتوفر لدي معلومات كافية للإجابة عن هذا السؤال بدقة. "
        "يرجى التواصل مع إدارة جامعتك أو توضيح سؤالك."
    ),
}

CATEGORY_LABELS = {
    "inscription": {"fr": "Inscription universitaire", "ar": "التسجيل الجامعي"},
    "documents": {"fr": "Documents administratifs", "ar": "الوثائق الإدارية"},
    "examens": {"fr": "Examens et résultats", "ar": "الامتحانات والنتائج"},
    "emploi_du_temps": {"fr": "Emploi du temps", "ar": "جدول التوقيت"},
    "bourses": {"fr": "Bourses", "ar": "المنح"},
    "bibliotheque": {"fr": "Bibliothèque", "ar": "المكتبة"},
    "services": {"fr": "Services universitaires", "ar": "الخدمات الجامعية"},
    "vie_etudiante": {"fr": "Vie étudiante", "ar": "الحياة الطلابية"},
    "orientation": {"fr": "Orientation générale", "ar": "التوجيه العام"},
}
