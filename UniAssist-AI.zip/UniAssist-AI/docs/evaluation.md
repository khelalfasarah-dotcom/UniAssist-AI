# Évaluation de UniAssist AI

## 1. Statut des résultats

> **L'évaluation avec le vrai modèle n'a pas encore été exécutée.** L'environnement de développement de ce projet n'avait
> ni accès à Internet ni sentence-transformers. Aucun chiffre de performance n'est donc donné. Pour l'obtenir :
> `python scripts/evaluate.py --split dev --sweep` puis `python scripts/evaluate.py --split test`.
> Collez ensuite les résultats réels dans la section 6 de ce fichier et dans le README.

## 2. Protocole

- `data/eval_set.json` contient 54 questions : 34 avec réponse attendue (17 FR, 17 AR) et 20 sans réponse attendue
  (hors sujet, ambiguës, ou liées à l'université mais absentes de la base).
- Les questions avec réponse sont des **reformulations** de sujets présents dans la FAQ : elles ne reprennent pas
  les formulations de `faq.json` (un test automatique vérifie l'absence de copie exacte).
- **Séparation dev / test** : `dev` (25 questions) sert à choisir le seuil ; `test` (29 questions) sert à mesurer le résultat
  final avec ce seuil. Ne modifiez pas le seuil en regardant `test`, sinon `test` devient une deuxième base de développement.

## 3. Métriques (définitions exactes)

| Métrique | Définition |
|---|---|
| Top-1 recherche | Parmi les questions avec réponse attendue : part où l'entrée classée **première** est la bonne (indépendante du seuil). |
| Répond juste | Part des questions avec réponse attendue où le système répond (score ≥ seuil) **et** avec la bonne entrée. |
| Faux rejet | Part des questions avec réponse attendue refusées à tort. |
| Mauvaise réponse | Part des questions avec réponse attendue où le système répond avec une autre entrée. |
| Rejet correct | Parmi les questions sans réponse attendue : part refusée. |
| Fausse acceptation | 1 − rejet correct. |

À ne pas confondre :
- **score de similarité** : valeur par question, outil de décision interne ;
- **précision de la recherche** : métrique agrégée ci-dessus, mesurée sur des étiquettes ;
- **exactitude des réponses** : la réponse est-elle administrativement vraie ? Non mesurée : la FAQ est générique ;
- **qualité linguistique** : fluidité et correction du texte arabe/français. Non mesurée ; elle dépend de la rédaction manuelle.

## 4. Limites méthodologiques

- **Très petit échantillon** (≈ 9 à 17 questions par catégorie) : un seul cas changé modifie les pourcentages de plusieurs points. Il n'y a pas d'intervalle de confiance.
- **Auteur unique** : la même personne a écrit la FAQ et les questions de test ; ses habitudes de formulation biaisent le test vers le « facile ».
- **Biais entre langues** : les questions françaises et arabes ont été écrites en parallèle (traduction implicite), ce qui est plus facile pour un modèle multilingue que des questions arabes spontanées, dialectales ou en alphabet latin (« arabizi »), non prises en charge par ce test.
- **Questions « sans réponse »** : choisies par l'auteur ; un utilisateur réel posera des questions plus variées.
- **Étiquette unique** : on suppose une seule bonne entrée par question, alors que plusieurs entrées peuvent être pertinentes.

## 5. Améliorations possibles

Faire écrire des questions par d'autres étudiants, ajouter des questions dialectales (darija) et mélangées FR/AR, utiliser plusieurs
étiquettes valides, mesurer top-3, comparer d'autres modèles, intégrer un re-classement.

## 6. Résultats réellement obtenus

*(À compléter après exécution : modèle, version de sentence-transformers, seuil retenu et justification, tableau du rapport `reports/evaluation_test.md`, analyse des erreurs.)*
