# Préparation à l'entretien Campus France — UniAssist AI

> Règle d'or : ne dites que ce qui est vrai. Ce projet utilise un modèle **préentraîné** (vous ne l'avez pas entraîné) et,
> tant que vous n'avez pas lancé `scripts/evaluate.py`, vous n'avez **aucun résultat chiffré** à citer.
> Relisez le code, lancez l'application, modifiez quelque chose (seuil, une entrée de FAQ) : cela rendra vos réponses authentiques.

## 1. Présentation orale (≈ 1 minute)

« J'ai développé UniAssist AI, un assistant bilingue français-arabe pour répondre aux questions fréquentes des étudiants :
inscription, documents, examens, emploi du temps, bourses. L'utilisateur pose sa question en français ou en arabe ; le système
la transforme en vecteur grâce à un modèle Sentence Transformers préentraîné, la compare à une base de questions et renvoie la
réponse associée. Si aucune question n'est assez proche, il refuse de répondre au lieu d'inventer. J'ai construit l'interface avec
Gradio, écrit des tests automatisés et un protocole d'évaluation séparé. C'est un projet pédagogique : les réponses sont génériques
et doivent être validées par une université. Il m'a permis de comprendre concrètement le NLP, la recherche sémantique et l'importance d'évaluer honnêtement un système. »

## 2. Présentation technique (≈ 3 minutes)

« Le projet est organisé en modules : `knowledge_base.py` lit et valide un fichier JSON de 41 entrées bilingues ; `chatbot.py` contient
le moteur ; `app.py` l'interface Gradio ; `config.py` les paramètres.
Au démarrage, le modèle `paraphrase-multilingual-MiniLM-L12-v2` encode toutes les formulations de la FAQ (environ 170) en vecteurs de 384 dimensions,
normalisés. Pour une question, je la normalise, je l'encode et je calcule le produit scalaire avec tous les vecteurs : comme ils sont normalisés,
c'est la similarité cosinus. Je garde la meilleure formulation de chaque entrée puis les trois meilleures entrées. Si le meilleur score est inférieur à un seuil
configurable, le système répond qu'il n'a pas d'information fiable ; sinon il renvoie la réponse dans la langue choisie.
J'ai évité une base vectorielle externe, inutile à cette taille. Le moteur reçoit son encodeur en paramètre, ce qui permet de tester avec un encodeur factice, sans télécharger le modèle.
Les tests couvrent le chargement des données, les erreurs, le rejet des questions vides et inconnues. L'évaluation est un script distinct avec un jeu séparé en dev (pour régler le seuil) et test (pour mesurer),
et des métriques définies : top-1 de recherche, bonnes réponses, faux rejets, rejets corrects. Les limites : petite base, jeu de test rédigé par une seule personne, pas de dialecte. »

## 3. Questions techniques possibles (avec réponses simples)

1. **Qu'est-ce que Hugging Face ?** Une plateforme et une communauté qui hébergent des modèles, jeux de données et bibliothèques d'IA, téléchargeables gratuitement (le « Hub »).
2. **Qu'est-ce que Sentence Transformers ?** Une bibliothèque qui fournit des modèles transformant une phrase en vecteur (embedding) dont la proximité reflète le sens.
3. **Qu'est-ce qu'un embedding ?** Une liste de nombres représentant une phrase ; des phrases de sens proche ont des vecteurs proches.
4. **Qu'est-ce que la similarité cosinus ?** Le cosinus de l'angle entre deux vecteurs ; proche de 1 = même direction = sens proche.
5. **Pourquoi normaliser les vecteurs ?** Pour que le produit scalaire égale directement le cosinus, ce qui simplifie et accélère le calcul.
6. **Le score est-il une probabilité ?** Non. C'est une mesure de proximité dont l'échelle dépend du modèle ; 0,7 ne veut pas dire 70 % de réussite.
7. **Pourquoi un seuil ?** Pour éviter de répondre à une question sans rapport avec la base. Il se règle en comparant questions connues et inconnues.
8. **Comment avez-vous calibré le seuil ?** *(À dire seulement si fait)* Avec `--sweep` sur le split dev, puis mesure sur test. Sinon : « Le seuil par défaut est provisoire ; je sais comment le calibrer et j'ai prévu le protocole. »
9. **Pourquoi pas ChatGPT ou un modèle génératif ?** Un modèle génératif peut inventer des règles administratives ; ici chaque réponse est écrite à l'avance, donc vérifiable. Choix de sécurité et de simplicité.
10. **Pourquoi pas une base vectorielle (FAISS, Chroma) ?** 170 vecteurs : NumPy suffit. J'ajouterais une base si la FAQ grandissait fortement.
11. **Comment gérez-vous deux langues ?** Le modèle est multilingue : français et arabe sont projetés dans le même espace. Chaque entrée a ses deux réponses ; on répond dans la langue choisie.
12. **Comment détectez-vous la langue ?** En comptant les lettres arabes et latines. C'est simple et limité : l'anglais est traité comme du français.
13. **Quel est le rôle de Gradio ?** Créer rapidement une interface web en Python (zone de texte, boutons, chatbot) sans écrire de HTML/JavaScript.
14. **Comment testez-vous sans télécharger le modèle ?** J'injecte un encodeur factice (hachage de mots) et je mocke le chargement. Ces tests vérifient la logique, pas la qualité du vrai modèle.
15. **Quelles métriques utilisez-vous ?** Top-1 de recherche, taux de bonnes réponses, faux rejets, mauvaises réponses, rejets corrects — définies dans `docs/evaluation.md`.
16. **Quelle différence entre précision de recherche et exactitude de la réponse ?** La première dit si on a retrouvé la bonne entrée ; la seconde si le contenu est vrai pour une université précise. Je ne mesure que la première.
17. **Quelles sont les limites de votre évaluation ?** Petit jeu, un seul auteur, questions rédigées en parallèle FR/AR, pas de dialecte, une seule étiquette valide par question.
18. **Que se passe-t-il si le modèle ne se télécharge pas ?** Le programme affiche un message expliquant la cause probable (réseau, disque) et les étapes ; l'interface indique que le chatbot est indisponible.
19. **Comment éviteriez-vous les erreurs sur les informations administratives ?** En ne mettant aucune date ou règle officielle inventée, en rappelant de vérifier, et en faisant valider la base par une administration.
20. **Comment amélioreriez-vous le projet ?** Plus de données validées, dialecte, plusieurs suggestions, comparaison de modèles, évaluation par d'autres étudiants, déploiement.

## 4. Comprendre les notions clés (rappel court)

- **Hugging Face** : où l'on trouve le modèle utilisé. **Sentence Transformers** : la bibliothèque qui l'exécute.
- **Embedding / cosinus / seuil** : voir questions 3 à 7. **Gradio** : l'interface.
- **Tests** : vérifient que le code fait ce qu'on attend. **Métriques** : mesurent, sur des exemples étiquetés, la qualité de la recherche.

## 5. Limites et améliorations (à dire honnêtement)

Limites : base petite et générique ; dialecte non évalué ; seuil à calibrer ; détection de langue rudimentaire ; pas de contexte conversationnel.
Améliorations : données validées par une université, évaluation plus large, comparaison de modèles, suggestions multiples, déploiement Spaces.

## 6. Votre contribution personnelle

Ce projet a été conçu avec l'aide d'un assistant IA qui a produit le code et les documents de départ. Pour pouvoir le défendre,
**faites et notez ce que vous avez réellement fait** ; ne retenez dans l'entretien que les points cochés :

- [ ] J'ai installé l'environnement et lancé l'application sur ma machine.
- [ ] J'ai lu et compris chaque module (je peux expliquer `search` et `answer` sans notes).
- [ ] J'ai modifié ou ajouté des entrées de FAQ en arabe et en français.
- [ ] J'ai exécuté `pytest` et corrigé ce qui échouait.
- [ ] J'ai exécuté l'évaluation, calibré le seuil sur dev et noté les résultats **réels** sur test.
- [ ] J'ai ajouté mes propres questions de test (idéalement avec l'aide d'autres étudiants).

Formulation honnête possible : « J'ai utilisé un modèle préentraîné et un assistant IA pour structurer le projet ; j'ai ensuite [ce que vous avez fait] et je peux expliquer chaque partie. »
Ne dites jamais que vous avez entraîné le modèle, ni que vous avez obtenu un pourcentage que vous n'avez pas mesuré.

## 7. Textes prêts à l'emploi

**Résumé pour le CV (à compléter après vérification)** :
« UniAssist AI — Chatbot bilingue français-arabe (Python, Sentence Transformers, Gradio) : recherche sémantique multilingue avec seuil de rejet, tests pytest, protocole d'évaluation, documentation GitHub. »
Ajoutez un résultat chiffré **uniquement** s'il provient de votre exécution réelle.

**Description pour le portfolio GitHub** :
« UniAssist AI est un projet pédagogique de NLP : un assistant étudiant bilingue français-arabe qui retrouve, grâce à un modèle d'embeddings préentraîné, la question la plus proche dans une base de connaissances et refuse de répondre lorsque la correspondance est insuffisante. Le dépôt comprend une interface Gradio, des tests automatisés, un jeu et un script d'évaluation, ainsi qu'une documentation technique. Les réponses sont génériques et non officielles. »
