# Publication sur GitHub et vérifications

## Description du dépôt (106 caractères)

`Chatbot étudiant bilingue français-arabe : recherche sémantique Sentence Transformers et interface Gradio.`

## Sujets (topics) GitHub

`nlp` `chatbot` `sentence-transformers` `huggingface` `gradio` `semantic-search` `multilingual` `arabic` `french` `python` `pytest` `faq-bot` `student-project`

## Procédure de vérification avant publication

1. Environnement propre : créer un nouvel environnement virtuel, `pip install -r requirements-dev.txt`.
2. `pytest` : tous les tests doivent passer **réellement** ; sinon corriger (ne pas publier de capture mensongère).
3. `python app.py` : tester 3 questions FR, 3 AR, 3 hors sujet ; vérifier l'affichage arabe et le bandeau de refus ; faire les captures (`assets/README.md`).
4. `python scripts/evaluate.py --split dev --sweep` : choisir un seuil ; le fixer dans `config.py` ; mettre à jour le commentaire « provisoire ».
5. `python scripts/evaluate.py --split test` : copier les **vrais** résultats dans `README.md` et `docs/evaluation.md` (section 6), et le statut de vérification.
6. Relire la licence et les langues sur la fiche Hugging Face du modèle ; remplacer « Sara » dans `LICENSE` par votre nom complet si vous le souhaitez.
7. Vérifier l'absence de secrets/données personnelles : `git status`, `git diff --cached`.
8. Relire `docs/interview_preparation.md` et adapter la section « ma contribution » à ce que vous avez réellement fait.

## Commandes Git

```bash
git init
git add .
git status                # vérifier : pas de .venv, pas de caches
git commit -m "UniAssist AI : chatbot bilingue FR-AR (version initiale)"
git branch -M main
git remote add origin https://github.com/<votre-compte>/UniAssist-AI.git
git push -u origin main
```
Créez d'abord un dépôt vide sur github.com (sans README ni licence générés), puis ajoutez la description et les sujets ci-dessus.
Si vous commitez `reports/`, ne le faites qu'avec de vrais rapports.

## Déploiement facultatif : Hugging Face Spaces

À ne tenter qu'après un fonctionnement local validé. Créez un Space de type **Gradio** (CPU gratuit, sous réserve des limites actuelles du service),
ajoutez en tête du README du Space :

```yaml
---
title: UniAssist AI
sdk: gradio
app_file: app.py
---
```
Poussez les mêmes fichiers (`app.py`, modules, `data/`, `requirements.txt`). Ne mentionnez « déployé » dans le README ou le CV
qu'une fois le Space réellement en ligne et testé. Remarque : le README GitHub et celui du Space peuvent différer (l'en-tête YAML n'est utile que sur Hugging Face).
