# Architecture de UniAssist AI

## 1. Vue d'ensemble

UniAssist AI est un système de **recherche de question la plus proche** (et non un modèle génératif) :
la réponse affichée est toujours un texte écrit à l'avance dans `data/faq.json`.

```
Question utilisateur ──► validation/normalisation ──► embedding (modèle) ──► similarité cosinus
                                                                              │ avec les questions de la FAQ
                                              score ≥ seuil ? ◄───────────────┘
                                   oui │                    │ non
                      réponse de l'entrée trouvée     message « pas assez pertinent »
                      (langue FR ou AR choisie)
```

## 2. Rôle de chaque fichier

| Fichier | Rôle |
|---|---|
| `config.py` | Chemins, nom du modèle, seuil, messages de refus, libellés de catégories. |
| `knowledge_base.py` | Lit et **valide** `data/faq.json` ; fournit des objets `FAQEntry`. |
| `chatbot.py` | Normalisation, détection d'alphabet, chargement du modèle, recherche et décision de refus (`UniAssistBot`). |
| `app.py` | Interface Gradio ; aucune logique de recherche. |
| `scripts/evaluate.py` | Évaluation avec le vrai modèle, rapports dans `reports/`. |
| `data/faq.json` | Base de connaissances bilingue (41 entrées). |
| `data/eval_set.json` | Jeu d'évaluation indépendant (split `dev` / `test`). |
| `tests/` | Tests pytest avec encodeur factice (pas de téléchargement). |

**Changement par rapport à la structure proposée** : ajout de `scripts/` (évaluation), de `requirements-dev.txt`
(pytest séparé des dépendances d'exécution), de `pytest.ini` (chemin d'import) et de `data/eval_set.json`
(le jeu d'évaluation est une donnée, pas du code).

## 3. Parcours d'une question

1. `app.py` reçoit le texte et la langue choisie (auto / français / arabe).
2. `validate_question` normalise (Unicode NFKC, suppression des voyelles brèves arabes et du tatweel,
   espaces) et rejette les questions vides ou de plus de 500 caractères.
3. `detect_language` (si « auto ») compare le nombre de lettres arabes et latines.
4. `UniAssistBot.search` encode la question, puis calcule le produit scalaire avec la matrice des vecteurs de la FAQ.
5. On garde, pour chaque entrée, sa **meilleure** formulation, puis les `TOP_K` meilleures entrées.
6. Si le meilleur score ≥ seuil → la réponse de l'entrée est renvoyée **dans la langue choisie**
   (même si la question correspondante était dans l'autre langue). Sinon → message de refus.

## 4. Embeddings et similarité cosinus

Un **embedding** est une liste de nombres (ici 384) qui représente le sens d'une phrase : deux phrases de sens proche
ont des vecteurs proches, même dans deux langues. Le modèle multilingue a été entraîné pour cela ; nous ne l'entraînons pas.

La **similarité cosinus** mesure l'angle entre deux vecteurs : `cos(a, b) = a·b / (‖a‖‖b‖)`. Nous normalisons tous les vecteurs
(norme 1) une fois pour toutes ; le produit scalaire devient alors directement le cosinus (entre -1 et 1).

**Un score cosinus n'est pas une probabilité.** 0,70 ne signifie pas « 70 % de chances que la réponse soit juste ».
C'est une distance géométrique entre deux phrases, dont l'échelle dépend du modèle. Seule l'évaluation sur des exemples
étiquetés (voir `docs/evaluation.md`) permet de dire à quelle fréquence le système se trompe.

## 5. Seuil de rejet

Le chatbot refuse de répondre lorsque `meilleur score < seuil`. Le seuil par défaut (0,50) est **provisoire et non calibré** :
il se règle dans `config.py` ou via `UNIASSIST_THRESHOLD`. Un seuil trop bas produit des réponses hors sujet ;
trop haut, des refus injustifiés. La calibration se fait sur le split `dev` (`--sweep`), puis se mesure sur `test`.

## 6. Décisions de conception

- **Recherche en NumPy, pas de base vectorielle** : 168 vecteurs ; une simple multiplication matricielle suffit.
- **Encodeur injecté** dans `UniAssistBot` : les tests utilisent un encodeur factice, donc pas de torch ni de téléchargement.
- **Import différé de `sentence_transformers`** : l'application affiche une erreur claire si la bibliothèque ou le modèle manque.
- **Réponses préécrites** : pas d'hallucination possible, mais aucune généralisation au-delà de la FAQ.
- **Langue de réponse indépendante de la langue de la question** : une même entrée contient les deux réponses.
- **Pas de journalisation des questions** : aucune donnée personnelle collectée.
