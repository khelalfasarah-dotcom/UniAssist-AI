"""Chargement et validation de la base de connaissances (data/faq.json)."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from config import FAQ_PATH

REQUIRED_TEXT_FIELDS = (
    "id",
    "category",
    "question_fr",
    "question_ar",
    "answer_fr",
    "answer_ar",
)
OPTIONAL_LIST_FIELDS = ("alternatives_fr", "alternatives_ar")


class KnowledgeBaseError(Exception):
    """Erreur de lecture ou de validation de la base de connaissances."""


@dataclass(frozen=True)
class FAQEntry:
    """Une entrée de FAQ bilingue."""

    id: str
    category: str
    questions_fr: tuple[str, ...]
    questions_ar: tuple[str, ...]
    answer_fr: str
    answer_ar: str
    source: str = ""

    def answer(self, language: str) -> str:
        """Retourne la réponse dans la langue demandée ('fr' ou 'ar')."""
        return self.answer_ar if language == "ar" else self.answer_fr

    def indexed_questions(self) -> list[str]:
        """Toutes les formulations de question (FR puis AR) à indexer."""
        return list(self.questions_fr) + list(self.questions_ar)


def _is_text_list(value: object) -> bool:
    return isinstance(value, list) and all(
        isinstance(item, str) and item.strip() for item in value
    )


def parse_entries(data: object) -> list[FAQEntry]:
    """Valide les données JSON déjà chargées et construit les entrées."""
    if not isinstance(data, dict) or "entries" not in data:
        raise KnowledgeBaseError(
            "Format invalide : le fichier doit être un objet JSON contenant la clé 'entries'."
        )
    raw_entries = data["entries"]
    if not isinstance(raw_entries, list) or not raw_entries:
        raise KnowledgeBaseError(
            "La base de connaissances est vide : 'entries' doit être une liste non vide."
        )

    problems: list[str] = []
    entries: list[FAQEntry] = []
    seen_ids: set[str] = set()

    for position, item in enumerate(raw_entries, start=1):
        label = f"entrée n°{position}"
        if not isinstance(item, dict):
            problems.append(f"{label} : doit être un objet JSON.")
            continue

        item_problems: list[str] = []
        for field in REQUIRED_TEXT_FIELDS:
            value = item.get(field)
            if not isinstance(value, str) or not value.strip():
                item_problems.append(f"{label} : champ '{field}' manquant ou vide.")
        for field in OPTIONAL_LIST_FIELDS:
            if field in item and not _is_text_list(item[field]):
                item_problems.append(
                    f"{label} : '{field}' doit être une liste de textes non vides."
                )
        entry_id = item.get("id")
        if isinstance(entry_id, str) and entry_id in seen_ids:
            item_problems.append(f"{label} : identifiant en double ({entry_id}).")

        if item_problems:
            problems.extend(item_problems)
            continue

        seen_ids.add(entry_id)
        entries.append(
            FAQEntry(
                id=entry_id,
                category=item["category"],
                questions_fr=(item["question_fr"], *item.get("alternatives_fr", [])),
                questions_ar=(item["question_ar"], *item.get("alternatives_ar", [])),
                answer_fr=item["answer_fr"],
                answer_ar=item["answer_ar"],
                source=item.get("source", ""),
            )
        )

    if problems:
        shown = "\n- ".join(problems[:10])
        more = f"\n(… et {len(problems) - 10} autre(s) problème(s))" if len(problems) > 10 else ""
        raise KnowledgeBaseError(f"Base de connaissances invalide :\n- {shown}{more}")
    return entries


def load_knowledge_base(path: Path | str = FAQ_PATH) -> list[FAQEntry]:
    """Charge et valide le fichier JSON de la base de connaissances."""
    path = Path(path)
    if not path.is_file():
        raise KnowledgeBaseError(
            f"Fichier de données introuvable : {path}. "
            "Vérifiez que data/faq.json existe (voir README, section « Structure de la base »)."
        )
    try:
        with path.open(encoding="utf-8") as handle:
            data = json.load(handle)
    except json.JSONDecodeError as exc:
        raise KnowledgeBaseError(
            f"JSON mal formé dans {path} (ligne {exc.lineno}, colonne {exc.colno}) : {exc.msg}."
        ) from exc
    except OSError as exc:
        raise KnowledgeBaseError(f"Impossible de lire {path} : {exc}") from exc
    return parse_entries(data)
