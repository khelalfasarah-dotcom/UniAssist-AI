# Captures d'écran à réaliser

Aucune capture n'est fournie : elles doivent être prises **après un vrai lancement** (`python app.py`).
Enregistrez-les dans ce dossier (PNG) puis référencez-les dans le README.

1. `01-accueil.png` : page d'accueil complète (titre, présentation, choix de la langue).
2. `02-question-fr.png` : une question en français avec sa réponse et la ligne de catégorie/similarité.
3. `03-question-ar.png` : une question en arabe avec sa réponse (vérifier l'affichage de droite à gauche).
4. `04-question-inconnue.png` : une question hors sujet, avec le bandeau « Aucune réponse suffisamment pertinente ».
5. `05-limites.png` : le panneau « Limites et caractère pédagogique » déplié.
6. `06-tests.png` : le terminal après `pytest` (uniquement si les tests passent réellement).
7. `07-evaluation.png` : le terminal ou le rapport `reports/evaluation_test.md` (uniquement après une vraie évaluation).
