"""Moteur de recherche sémantique de UniAssist AI (sans dépendance à Gradio)."""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass, field
from typing import Protocol, Sequence

import numpy as np

from config import (
    MAX_QUESTION_LENGTH,
    MODEL_NAME,
    NO_ANSWER_MESSAGES,
    SIMILARITY_THRESHOLD,
    TOP_K,
)
from knowledge_base import FAQEntry

LANGUAGE_CHOICES = ("auto", "fr", "ar")


class ChatbotError(Exception):
    """Classe de base des erreurs du chatbot."""


class ModelLoadError(ChatbotError):
    """Le modèle d'embeddings n'a pas pu être chargé."""


class InvalidInputError(ChatbotError):
    """La question ou un paramètre fourni par l'utilisateur est invalide."""


class Encoder(Protocol):
    """Ce que le chatbot attend d'un encodeur (SentenceTransformer le respecte)."""

    def encode(self, sentences: Sequence[str], **kwargs): ...


# --------------------------------------------------------------------------- #
# Traitement des questions
# --------------------------------------------------------------------------- #
def normalize_text(text: str) -> str:
    """Normalise un texte : Unicode NFKC, suppression des diacritiques arabes
    (harakat) et du tatweel, espaces multiples réduits."""
    text = unicodedata.normalize("NFKC", text)
    cleaned = []
    for char in text:
        code = ord(char)
        if 0x064B <= code <= 0x065F or code in (0x0670, 0x0640):
            continue
        cleaned.append(char)
    return " ".join("".join(cleaned).split())


def _is_arabic_letter(char: str) -> bool:
    code = ord(char)
    return char.isalpha() and (
        0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F or 0xFB50 <= code <= 0xFEFF
    )


def detect_language(text: str) -> str:
    """Détection simple par alphabet : 'ar' si les lettres arabes dominent,
    sinon 'fr'. Limite : un texte en alphabet latin (anglais, arabizi…) est
    considéré comme 'fr' ; il s'agit d'un choix de la langue de réponse, pas
    d'une identification de la langue réelle."""
    arabic = sum(1 for c in text if _is_arabic_letter(c))
    latin = sum(1 for c in text if c.isalpha() and not _is_arabic_letter(c))
    return "ar" if arabic > latin else "fr"


def validate_question(question: object) -> str:
    """Vérifie et normalise une question ; lève InvalidInputError sinon."""
    if not isinstance(question, str):
        raise InvalidInputError("La question doit être un texte.")
    clean = normalize_text(question)
    if not clean:
        raise InvalidInputError(
            "La question est vide. Veuillez saisir une question. / السؤال فارغ، يرجى كتابة سؤال."
        )
    if len(clean) > MAX_QUESTION_LENGTH:
        raise InvalidInputError(
            f"La question est trop longue ({len(clean)} caractères ; maximum {MAX_QUESTION_LENGTH})."
        )
    return clean


# --------------------------------------------------------------------------- #
# Chargement du modèle
# --------------------------------------------------------------------------- #
def load_encoder(model_name: str = MODEL_NAME) -> Encoder:
    """Charge le modèle Sentence Transformers (import différé : les tests et la
    validation des données n'ont pas besoin de torch)."""
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise ModelLoadError(
            "La bibliothèque 'sentence-transformers' n'est pas installée. "
            "Activez votre environnement virtuel puis exécutez : "
            "pip install -r requirements.txt"
        ) from exc
    try:
        return SentenceTransformer(model_name)
    except Exception as exc:  # erreurs réseau, disque, cache corrompu…
        raise ModelLoadError(
            f"Impossible de charger le modèle « {model_name} » ({type(exc).__name__} : {exc}). "
            "Le premier lancement nécessite une connexion Internet pour télécharger le modèle "
            "(environ quelques centaines de Mo). Vérifiez votre connexion, l'espace disque, "
            "puis relancez ; une fois téléchargé, le modèle est réutilisé depuis le cache local."
        ) from exc


# --------------------------------------------------------------------------- #
# Résultats
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Match:
    entry_id: str
    category: str
    score: float  # similarité cosinus, PAS une probabilité
    matched_text: str


@dataclass(frozen=True)
class ChatResponse:
    answer: str
    found: bool
    language: str
    score: float
    entry_id: str | None = None
    category: str | None = None
    matches: list[Match] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Moteur
# --------------------------------------------------------------------------- #
class UniAssistBot:
    """Recherche la question de la FAQ la plus proche sémantiquement."""

    def __init__(
        self,
        entries: Sequence[FAQEntry],
        encoder: Encoder,
        threshold: float = SIMILARITY_THRESHOLD,
        top_k: int = TOP_K,
    ) -> None:
        if not entries:
            raise ChatbotError("La base de connaissances est vide.")
        if not -1.0 <= threshold <= 1.0:
            raise ChatbotError("Le seuil doit être compris entre -1 et 1.")
        if top_k < 1:
            raise ChatbotError("top_k doit être supérieur ou égal à 1.")

        self._entries = list(entries)
        self._by_id = {entry.id: entry for entry in self._entries}
        self._encoder = encoder
        self.threshold = threshold
        self._top_k = top_k

        self._texts: list[str] = []
        self._owners: list[int] = []  # indice de l'entrée propriétaire de chaque texte
        for index, entry in enumerate(self._entries):
            for text in entry.indexed_questions():
                self._texts.append(normalize_text(text))
                self._owners.append(index)
        self._matrix = self._encode(self._texts)

    def _encode(self, texts: list[str]) -> np.ndarray:
        """Encode puis normalise les vecteurs (norme 1) : le produit scalaire
        de deux vecteurs normalisés est alors égal à leur similarité cosinus."""
        vectors = np.asarray(
            self._encoder.encode(texts, convert_to_numpy=True, show_progress_bar=False),
            dtype=np.float32,
        )
        if vectors.ndim != 2 or vectors.shape[0] != len(texts):
            raise ChatbotError("L'encodeur a retourné des vecteurs de forme inattendue.")
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return vectors / norms

    def search(self, question: str) -> list[Match]:
        """Retourne les `top_k` entrées les plus proches (une seule ligne par entrée)."""
        clean = validate_question(question)
        query = self._encode([clean])[0]
        scores = self._matrix @ query
        matches: list[Match] = []
        seen: set[int] = set()
        for idx in np.argsort(-scores, kind="stable"):
            owner = self._owners[idx]
            if owner in seen:
                continue
            seen.add(owner)
            entry = self._entries[owner]
            matches.append(
                Match(entry.id, entry.category, float(scores[idx]), self._texts[idx])
            )
            if len(matches) >= self._top_k:
                break
        return matches

    def answer(self, question: str, language: str = "auto") -> ChatResponse:
        """Répond à une question, ou refuse si la similarité est sous le seuil."""
        if language not in LANGUAGE_CHOICES:
            raise InvalidInputError(f"Langue non prise en charge : {language!r}.")
        clean = validate_question(question)
        lang = detect_language(clean) if language == "auto" else language
        matches = self.search(clean)
        best = matches[0]
        if best.score < self.threshold:
            return ChatResponse(NO_ANSWER_MESSAGES[lang], False, lang, best.score, matches=matches)
        entry = self._by_id[best.entry_id]
        return ChatResponse(
            entry.answer(lang), True, lang, best.score, entry.id, entry.category, matches
        )
