"""Fixtures partagées : un encodeur factice (sans modèle, sans réseau).

HashingEncoder projette les mots d'un texte dans un vecteur par hachage : des
textes partageant des mots obtiennent une similarité cosinus élevée. Il sert
UNIQUEMENT à tester la logique du code ; il ne dit rien de la qualité du vrai
modèle sémantique.
"""

import hashlib
import re

import numpy as np
import pytest

from knowledge_base import FAQEntry


class HashingEncoder:
    def __init__(self, dim: int = 512) -> None:
        self.dim = dim
        self.calls = 0

    def encode(self, sentences, **kwargs):
        self.calls += 1
        vectors = np.zeros((len(sentences), self.dim), dtype=np.float32)
        for row, text in enumerate(sentences):
            for token in re.findall(r"\w+", text.lower()):
                digest = hashlib.md5(token.encode("utf-8")).hexdigest()
                vectors[row, int(digest, 16) % self.dim] += 1.0
        return vectors


@pytest.fixture
def encoder():
    return HashingEncoder()


@pytest.fixture
def mini_entries():
    return [
        FAQEntry(
            id="t-1",
            category="inscription",
            questions_fr=("Quels documents faut-il pour une inscription universitaire ?",),
            questions_ar=("ما هي الوثائق المطلوبة للتسجيل الجامعي؟",),
            answer_fr="Réponse FR inscription.",
            answer_ar="جواب التسجيل.",
        ),
        FAQEntry(
            id="t-2",
            category="bibliotheque",
            questions_fr=("Comment emprunter un livre à la bibliothèque ?",),
            questions_ar=("كيف أستعير كتابا من المكتبة؟",),
            answer_fr="Réponse FR bibliothèque.",
            answer_ar="جواب المكتبة.",
        ),
    ]
