"""Tests du calcul des métriques et de la cohérence du jeu d'évaluation."""

import json

import pytest

from config import EVAL_SET_PATH, FAQ_PATH
from knowledge_base import load_knowledge_base
from scripts.evaluate import compute_metrics, load_eval_items


def rec(expected, top_id, score, lang="fr", typ="paraphrase"):
    return {"id": "r", "lang": lang, "type": typ, "question": "q",
            "expected_id": expected, "top_id": top_id, "top_score": score}


def test_metrics_are_computed_as_defined():
    records = [
        rec("a", "a", 0.9),          # répond juste
        rec("a", "b", 0.8),          # mauvaise réponse (top-1 faux)
        rec("a", "a", 0.2),          # top-1 juste mais faux rejet
        rec(None, "a", 0.1, typ="off_topic"),    # rejet correct
        rec(None, "a", 0.7, typ="unanswerable"), # fausse acceptation
    ]
    overall = compute_metrics(records, threshold=0.5)["overall"]
    assert overall["n_answerable"] == 3 and overall["n_unanswerable"] == 2
    assert overall["top1_retrieval_accuracy"] == pytest.approx(2 / 3)
    assert overall["answered_correctly_rate"] == pytest.approx(1 / 3)
    assert overall["false_rejection_rate"] == pytest.approx(1 / 3)
    assert overall["wrong_answer_rate"] == pytest.approx(1 / 3)
    assert overall["correct_rejection_rate"] == pytest.approx(1 / 2)


def test_metrics_split_by_language_and_report_errors():
    records = [rec("a", "a", 0.9, lang="fr"), rec("a", "b", 0.9, lang="ar")]
    metrics = compute_metrics(records, 0.5)
    assert metrics["by_language"]["fr"]["answered_correctly_rate"] == 1.0
    assert metrics["by_language"]["ar"]["answered_correctly_rate"] == 0.0
    assert len(metrics["errors"]) == 1


def test_empty_subset_gives_none_not_crash():
    metrics = compute_metrics([rec("a", "a", 0.9, lang="fr")], 0.5)
    assert metrics["by_language"]["ar"]["top1_retrieval_accuracy"] is None


def test_eval_set_is_consistent_with_knowledge_base():
    ids = {e.id for e in load_knowledge_base(FAQ_PATH)}
    items = load_eval_items(EVAL_SET_PATH, "all")
    assert {i["split"] for i in items} == {"dev", "test"}
    assert {i["lang"] for i in items} == {"fr", "ar"}
    for item in items:
        assert item["expected_id"] is None or item["expected_id"] in ids


def test_eval_questions_are_not_copied_from_knowledge_base():
    kb_questions = {q.strip().lower() for e in load_knowledge_base(FAQ_PATH) for q in e.indexed_questions()}
    for item in load_eval_items(EVAL_SET_PATH, "all"):
        assert item["question"].strip().lower() not in kb_questions
