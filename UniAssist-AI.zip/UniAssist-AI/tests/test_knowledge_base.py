import json

import pytest

from config import FAQ_PATH
from knowledge_base import KnowledgeBaseError, load_knowledge_base, parse_entries


def valid_entry(**overrides):
    entry = {
        "id": "x-1",
        "category": "inscription",
        "question_fr": "Question ?",
        "question_ar": "سؤال؟",
        "answer_fr": "Réponse.",
        "answer_ar": "جواب.",
    }
    entry.update(overrides)
    return entry


def test_real_knowledge_base_loads_and_is_large_enough():
    entries = load_knowledge_base(FAQ_PATH)
    assert len(entries) >= 40
    assert len({e.id for e in entries}) == len(entries)


def test_real_knowledge_base_entries_have_complete_structure():
    for entry in load_knowledge_base(FAQ_PATH):
        assert entry.questions_fr and entry.questions_ar
        assert entry.answer_fr.strip() and entry.answer_ar.strip()
        assert entry.category


def test_missing_file_raises_clear_error(tmp_path):
    with pytest.raises(KnowledgeBaseError, match="introuvable"):
        load_knowledge_base(tmp_path / "absent.json")


def test_malformed_json_raises_clear_error(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text("{ pas du json", encoding="utf-8")
    with pytest.raises(KnowledgeBaseError, match="JSON mal formé"):
        load_knowledge_base(bad)


def test_empty_knowledge_base_is_rejected(tmp_path):
    path = tmp_path / "empty.json"
    path.write_text(json.dumps({"entries": []}), encoding="utf-8")
    with pytest.raises(KnowledgeBaseError, match="vide"):
        load_knowledge_base(path)


def test_missing_required_field_is_reported():
    entry = valid_entry()
    del entry["answer_ar"]
    with pytest.raises(KnowledgeBaseError, match="answer_ar"):
        parse_entries({"entries": [entry]})


def test_duplicate_ids_are_reported():
    with pytest.raises(KnowledgeBaseError, match="double"):
        parse_entries({"entries": [valid_entry(), valid_entry()]})


def test_alternatives_are_merged_into_questions():
    entries = parse_entries({"entries": [valid_entry(alternatives_fr=["Autre ?"])]})
    assert entries[0].questions_fr == ("Question ?", "Autre ?")
    assert len(entries[0].indexed_questions()) == 3


def test_answer_selects_language():
    entry = parse_entries({"entries": [valid_entry()]})[0]
    assert entry.answer("fr") == "Réponse."
    assert entry.answer("ar") == "جواب."
