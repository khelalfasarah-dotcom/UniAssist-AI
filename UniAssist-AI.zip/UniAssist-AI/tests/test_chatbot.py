import sys
import types

import pytest

from chatbot import (
    ChatbotError,
    InvalidInputError,
    ModelLoadError,
    UniAssistBot,
    detect_language,
    load_encoder,
    normalize_text,
    validate_question,
)
from config import NO_ANSWER_MESSAGES


@pytest.fixture
def bot(mini_entries, encoder):
    return UniAssistBot(mini_entries, encoder, threshold=0.4)


# --- traitement des questions -------------------------------------------------
def test_normalize_text_collapses_spaces_and_removes_arabic_diacritics():
    assert normalize_text("  Bonjour   le   monde ") == "Bonjour le monde"
    assert normalize_text("كِتَابٌ") == "كتاب"


def test_detect_language():
    assert detect_language("Où est la bibliothèque ?") == "fr"
    assert detect_language("أين المكتبة؟") == "ar"
    assert detect_language("12345") == "fr"


@pytest.mark.parametrize("bad", ["", "   ", "\n\t"])
def test_empty_question_is_rejected(bad):
    with pytest.raises(InvalidInputError, match="vide"):
        validate_question(bad)


def test_non_string_and_too_long_questions_are_rejected():
    with pytest.raises(InvalidInputError):
        validate_question(None)
    with pytest.raises(InvalidInputError, match="trop longue"):
        validate_question("a" * 5000)


# --- recherche ----------------------------------------------------------------
def test_existing_question_is_answered_in_french(bot):
    response = bot.answer("Quels documents faut-il pour une inscription universitaire ?")
    assert response.found
    assert response.entry_id == "t-1"
    assert response.answer == "Réponse FR inscription."
    assert response.score == pytest.approx(1.0, abs=1e-5)


def test_arabic_question_gets_arabic_answer(bot):
    response = bot.answer("كيف أستعير كتابا من المكتبة؟")
    assert response.found and response.entry_id == "t-2"
    assert response.language == "ar"
    assert response.answer == "جواب المكتبة."


def test_explicit_language_overrides_detection(bot):
    response = bot.answer("كيف أستعير كتابا من المكتبة؟", language="fr")
    assert response.answer == "Réponse FR bibliothèque."


def test_unknown_question_is_rejected_with_standard_message(bot):
    response = bot.answer("Quelle est la capitale du Japon ?")
    assert not response.found
    assert response.entry_id is None
    assert response.answer == NO_ANSWER_MESSAGES["fr"]


def test_unknown_arabic_question_gets_arabic_rejection(bot):
    response = bot.answer("من فاز بكأس العالم؟")
    assert not response.found
    assert response.answer == NO_ANSWER_MESSAGES["ar"]


def test_threshold_is_configurable(mini_entries, encoder):
    strict = UniAssistBot(mini_entries, encoder, threshold=0.99)
    assert not strict.answer("Comment emprunter un livre ?").found
    lenient = UniAssistBot(mini_entries, encoder, threshold=0.1)
    assert lenient.answer("Comment emprunter un livre ?").found


def test_search_returns_one_match_per_entry_sorted_by_score(bot):
    matches = bot.search("Comment emprunter un livre à la bibliothèque ?")
    assert [m.entry_id for m in matches][0] == "t-2"
    assert len({m.entry_id for m in matches}) == len(matches)
    assert matches == sorted(matches, key=lambda m: -m.score)


def test_empty_question_rejected_by_bot(bot):
    with pytest.raises(InvalidInputError):
        bot.answer("   ")


def test_invalid_language_rejected(bot):
    with pytest.raises(InvalidInputError):
        bot.answer("Bonjour", language="en")


def test_index_is_encoded_once_at_construction(mini_entries, encoder):
    bot = UniAssistBot(mini_entries, encoder, threshold=0.4)
    assert encoder.calls == 1
    bot.answer("Comment emprunter un livre ?")
    bot.answer("Comment emprunter un livre ?")
    assert encoder.calls == 3  # 1 pour l'index + 1 par question


def test_invalid_construction_parameters(mini_entries, encoder):
    with pytest.raises(ChatbotError):
        UniAssistBot([], encoder)
    with pytest.raises(ChatbotError):
        UniAssistBot(mini_entries, encoder, threshold=2.0)
    with pytest.raises(ChatbotError):
        UniAssistBot(mini_entries, encoder, top_k=0)


# --- chargement du modèle (mocké : aucun téléchargement) ----------------------
def test_load_encoder_without_library(monkeypatch):
    monkeypatch.setitem(sys.modules, "sentence_transformers", None)
    with pytest.raises(ModelLoadError, match="pip install"):
        load_encoder()


def test_load_encoder_network_failure_mentions_internet(monkeypatch):
    fake = types.ModuleType("sentence_transformers")

    def broken(*args, **kwargs):
        raise OSError("hors ligne")

    fake.SentenceTransformer = broken
    monkeypatch.setitem(sys.modules, "sentence_transformers", fake)
    with pytest.raises(ModelLoadError, match="Internet"):
        load_encoder("n'importe-quoi")


def test_load_encoder_success_returns_model_object(monkeypatch):
    fake = types.ModuleType("sentence_transformers")
    fake.SentenceTransformer = lambda name: ("modele", name)
    monkeypatch.setitem(sys.modules, "sentence_transformers", fake)
    assert load_encoder("m") == ("modele", "m")
