# 🎓 UniAssist AI

**Assistant étudiant bilingue français-arabe basé sur le NLP.**

Projet pédagogique : un chatbot qui répond aux questions fréquentes des étudiants (inscriptions, documents administratifs,
examens, emplois du temps, bourses, bibliothèque, services, vie étudiante) en retrouvant, par **similarité sémantique**,
la question la plus proche dans une base de connaissances bilingue, avec une interface **Gradio**.

> ⚠️ **Avertissement.** Les réponses sont **génériques et non officielles**. Les procédures varient selon l'établissement,
> le pays et l'année universitaire : elles doivent être adaptées et validées pour une université précise avant tout usage réel.

**Statut** : code, tests et jeu d'évaluation écrits ; l'évaluation avec le modèle réel et le lancement de l'interface
restent **à effectuer sur votre machine** (voir la section « État de vérification »).

## Problème traité

Les étudiants posent sans cesse les mêmes questions pratiques, en français ou en arabe, et l'information est dispersée.
Ce projet explore une première solution simple, transparente et gratuite.

## Objectifs

Développer une application Python structurée ; utiliser un modèle NLP préentraîné ; réaliser une recherche sémantique
multilingue ; gérer les questions inconnues ; tester et évaluer honnêtement ; documenter et publier sur GitHub.

## Fonctionnalités

- Questions en français ou en arabe, réponse dans la langue choisie (auto / français / arabe).
- Recherche sémantique multilingue (recherche interlangue possible : une question arabe peut retrouver une entrée écrite en français).
- Seuil de similarité configurable ; **refus explicite** quand aucune entrée n'est assez proche.
- Interface : historique, envoi, effacement, exemples, bandeau d'alerte, panneau des limites, affichage de droite à gauche via CSS.
- Gestion d'erreurs : fichier JSON absent ou invalide, base vide, question vide ou trop longue, modèle non téléchargeable.
- Tests pytest sans téléchargement du modèle ; script d'évaluation séparé.

## Technologies

Python ≥ 3.10 · [Sentence Transformers](https://www.sbert.net/) · Hugging Face Hub · NumPy · Gradio · pytest.

## Comment fonctionne le NLP ici (version simple)

1. Le modèle transforme chaque phrase en **embedding** (384 nombres représentant son sens).
2. La question de l'utilisateur est transformée de la même façon.
3. On calcule la **similarité cosinus** avec chaque question de la FAQ : plus elle est proche de 1, plus les sens sont proches.
4. Si le meilleur score dépasse le **seuil**, on affiche la réponse correspondante ; sinon on refuse.

Le score cosinus **n'est pas une probabilité** que la réponse soit correcte, ni la précision du chatbot. Détails : `docs/architecture.md`.

## Architecture et arborescence

```
UniAssist-AI/
├── app.py                  # interface Gradio
├── chatbot.py              # moteur : normalisation, modèle, recherche, refus
├── knowledge_base.py       # lecture et validation de data/faq.json
├── config.py               # chemins, modèle, seuil, messages
├── data/
│   ├── faq.json            # base de connaissances (41 entrées bilingues)
│   └── eval_set.json       # jeu d'évaluation (dev / test)
├── scripts/
│   └── evaluate.py         # évaluation reproductible avec le vrai modèle
├── tests/
│   ├── conftest.py         # encodeur factice
│   ├── test_knowledge_base.py
│   ├── test_chatbot.py
│   └── test_evaluate.py
├── docs/
│   ├── architecture.md
│   ├── evaluation.md
│   ├── interview_preparation.md
│   └── publication.md      # publication GitHub, vérifications, déploiement facultatif
├── assets/README.md        # liste des captures d'écran à réaliser
├── pytest.ini
├── requirements.txt
├── requirements-dev.txt
├── .gitignore
├── LICENSE
└── README.md
```

## Prérequis

- Python 3.10 ou plus récent ; ~2 Go d'espace disque (PyTorch + modèle) ; aucune carte graphique nécessaire (CPU).
- **Connexion Internet au premier lancement** : le modèle est téléchargé depuis Hugging Face puis mis en cache localement.

## Installation

**Windows (PowerShell)**
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
```
(Si l'activation est bloquée : `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.)

**Linux / macOS**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
```
Option pour limiter la taille sur machine sans GPU : installer PyTorch CPU avant, `pip install torch --index-url https://download.pytorch.org/whl/cpu`.

## Lancement

```bash
python app.py
```
Ouvrez ensuite l'adresse affichée (en général http://127.0.0.1:7860). Seuil personnalisé : `UNIASSIST_THRESHOLD=0.55 python app.py`
(Windows PowerShell : `$env:UNIASSIST_THRESHOLD="0.55"; python app.py`).

## Tests

```bash
pytest
```
Les tests n'ont besoin ni du modèle ni d'Internet (encodeur factice, mocks du chargement). Ils vérifient la logique du code,
pas la qualité sémantique du modèle réel.

## Évaluation

```bash
python scripts/evaluate.py --split dev --sweep   # choisir le seuil
python scripts/evaluate.py --split test          # mesure finale
```
Les rapports sont écrits dans `reports/`. Protocole, métriques et limites : `docs/evaluation.md`.

**Résultats obtenus : aucun pour l'instant — évaluation à effectuer.** Ne copiez ici que les chiffres réellement produits par le script.

## État de vérification

| Élément | Statut |
|---|---|
| Syntaxe de tous les fichiers Python | vérifiée (compilation) |
| Chargement et validation de `faq.json` (41 entrées) | vérifiés |
| Logique des tests (34 cas) | exécutée avec un substitut minimal de pytest, **pas** avec pytest lui-même |
| Chargement du vrai modèle, évaluation | **non exécutés** (pas d'Internet dans l'environnement de développement) |
| Interface Gradio | **non lancée** ; l'affichage de droite à gauche reste à vérifier visuellement |

## Structure de la base de connaissances

```json
{
  "metadata": { "...": "..." },
  "entries": [
    {
      "id": "faq-001",
      "category": "inscription",
      "question_fr": "…", "question_ar": "…",
      "alternatives_fr": ["…"], "alternatives_ar": ["…"],
      "answer_fr": "…", "answer_ar": "…",
      "source": "indication de vérification"
    }
  ]
}
```
Catégories : inscription, documents, examens, emploi_du_temps, bourses, bibliotheque, services, vie_etudiante, orientation.
Chaque réponse rappelle de vérifier auprès de l'administration ; aucune date limite, montant, adresse ou lien institutionnel n'est inventé.

## Limites connues

- Base petite (41 entrées) et générique ; aucune information propre à un établissement.
- Le modèle est multilingue mais pas parfait en arabe, et le **dialecte** (darija) ou l'arabizi ne sont pas évalués.
- La détection de langue est une simple comparaison d'alphabets ; une question en anglais sera traitée comme « français ».
- Une question à deux sujets ne reçoit qu'une réponse ; pas de mémoire de conversation.
- Le seuil par défaut (0,50) est provisoire tant qu'il n'a pas été calibré.
- Pas de génération de texte : le système ne peut répondre qu'avec ce qui est écrit dans la FAQ.

## Perspectives

Calibrer le seuil, enrichir la FAQ avec une université réelle (validée par l'administration), ajouter le dialecte, afficher plusieurs
suggestions, journaliser (avec consentement) les questions sans réponse, comparer plusieurs modèles, déployer sur Hugging Face Spaces.

## Licence et crédits

- Code : licence MIT (`LICENSE`).
- Modèle : `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` (Reimers & Gurevych, UKP Lab). **Vérifiez la licence
  et la liste des langues sur la fiche officielle du modèle (Hugging Face) avant publication** ; ce projet ne redistribue pas les poids du modèle.
- Références : Reimers & Gurevych, *Sentence-BERT* (EMNLP 2019) ; *Making Monolingual Sentence Embeddings Multilingual using Knowledge Distillation* (EMNLP 2020).
- Bibliothèques : sentence-transformers, PyTorch, NumPy, Gradio, pytest — vérifiez leurs licences respectives sur leurs dépôts.

## Précautions sur les informations administratives

Ce chatbot n'est pas une source officielle. Ne l'utilisez pas pour une décision administrative, financière ou juridique sans confirmation de l'administration.
Aucune donnée personnelle n'est collectée ni enregistrée par l'application.

## Compétences mises en œuvre

Python modulaire · NLP et embeddings · recherche sémantique multilingue · conception d'une base de connaissances · gestion d'erreurs ·
interface Gradio · tests unitaires avec mocks · protocole d'évaluation (dev/test, métriques) · documentation technique · Git/GitHub.

## Captures d'écran

À réaliser après lancement réel : voir `assets/README.md`.
